<center>
  <h1>Pay Offline Using Method</h1>
   <p class="text-muted">
      If you have any questios, feel free to <a href="../contact.php">Contact Us</a>.Our customer Service Work <strong>24/7</strong>
   </p>
</center>
<hr>
<div class="table-responsive">
  <table class="table table-bordered table-hover">
     <thead>
        <tr>
            <th>Bank Account Details</th>
            <th>Bkash/Rocket/DBBl Details</th>
            <th>Western Union Details</th>
          
            
        </tr>
     </thead>
     <tbody>
        <tr>
           <td>Bank Name:URL| Account No:100-909-032|Branch Name:Dhaka|Branch code:1497</td>
           <td>NIC #676-786-549 | Mobile No:0189657898 | Name:MD. Robin</td>
           <td>Real Name:Mr. Rezwan |Mobile No:018765984 |Country:Bangladesh |Name:Md.Rob |NIC #889-874-783</td>
        </tr>
     </tbody>
  </table>
</div>